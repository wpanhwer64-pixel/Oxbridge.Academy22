
function toggleMenu() {

      document.getElementById("nav-menu").classList.toggle("show");


      function toggleMenu() {
  document.getElementById("nav-menu").classList.toggle("show");
}

function toggleDropdown() {
  const dropdown = document.querySelector(".dropdown .dropdown-content");
  dropdown.classList.toggle("show");
  
}
  // Attach click event to dropdown toggles
  const dropdownToggles = document.querySelectorAll('.dropdown-toggle');
  dropdownToggles.forEach(toggle => {
    toggle.addEventListener('click', toggleDropdown);
  });

  // Close dropdown when clicking outside
  document.addEventListener('click', function(e) {
    dropdownToggles.forEach(toggle => {
      const dropdown = toggle.nextElementSibling;
      if (!toggle.contains(e.target) && !dropdown.contains(e.target)) {
        dropdown.classList.remove("show");
      }
    });
  });

  // Hamburger menu button (make sure HTML me button class="menu-btn" ho)
  const menuBtn = document.querySelector('.menu-btn');
  if(menuBtn){
    menuBtn.addEventListener('click', toggleMenu);
}

}
